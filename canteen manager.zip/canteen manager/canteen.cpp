#include <iostream>
#include <vector>
#include <string>

using namespace std;

// Class representing a single menu item
class MenuItem {
private:
    int itemId;
    string name;
    double price;

public:
    // Constructor to initialize item details
    MenuItem(int id, string n, double p) {
        itemId = id;
        name = n;
        price = p;
    }

    // Getter methods (Encapsulation)
    int getItemId() const { return itemId; }
    string getName() const { return name; }
    double getPrice() const { return price; }

    // Method to display item details
    void displayItem() const {
        cout << "[" << itemId << "] " << name << " - ₹" << price << endl;
    }
};

// Class representing the Canteen system
class Canteen {
private:
    vector<MenuItem> menu;

    // Helper structure for cart items
    struct CartItem {
        MenuItem item;
        int quantity;
    };

    // Initializes default menu items
    void initializeMenu() {
        menu.push_back(MenuItem(1, "Veg Burger", 60.0));
        menu.push_back(MenuItem(2, "French Fries", 50.0));
        menu.push_back(MenuItem(3, "Cold Coffee", 70.0));
        menu.push_back(MenuItem(4, "Veg Sandwich", 40.0));
    }

public:
    // Constructor
    Canteen() {
        initializeMenu();
    }

    // Displays the full menu
    void showMenu() const {
        cout << "\n--- Canteen Menu ---\n";
        for (const auto& item : menu) {
            item.displayItem();
        }
        cout << "--------------------\n";
    }

    // Handles customer ordering
    void placeOrder() {
        vector<CartItem> cart;
        int choice, quantity;

        while (true) {
            showMenu();
            cout << "Enter Item ID to order (or 0 to checkout): ";
            cin >> choice;

            if (choice == 0) {
                break;
            }

            // Search for the item in the menu
            MenuItem* selectedItem = nullptr;
            for (auto& item : menu) {
                if (item.getItemId() == choice) {
                    selectedItem = &item;
                    break;
                }
            }

            if (selectedItem != nullptr) {
                cout << "Enter quantity for " << selectedItem->getName() << ": ";
                cin >> quantity;

                if (quantity > 0) {
                    cart.push_back({*selectedItem, quantity});
                    cout << "Added " << quantity << " x " << selectedItem->getName() << " to your order.\n";
                } else {
                    cout << "Quantity must be greater than zero.\n";
                }
            } else {
                cout << "Invalid Item ID. Please try again.\n";
            }
        }

        generateBill(cart);
    }

    // Generates and prints the final bill
    void generateBill(const vector<CartItem>& cart) const {
        if (cart.empty()) {
            cout << "\nNo items ordered. Have a nice day!\n";
            return;
        }

        cout << "\n================================\n";
        cout << "       YOUR CANTEEN BILL        \n";
        cout << "================================\n";
        double totalAmount = 0;

        for (const auto& cartItem : cart) {
            double cost = cartItem.item.getPrice() * cartItem.quantity;
            totalAmount += cost;
            cout << cartItem.item.getName() << " (x" << cartItem.quantity << ") - ₹" << cost << endl;
        }

        cout << "--------------------------------\n";
        cout << "Total Amount: ₹" << totalAmount << endl;
        cout << "================================\n";
        cout << "Thank you! Visit again.\n\n";
    }
};

// Main Program Function
int main() {
    Canteen canteenSystem;
    int choice;

    do {
        cout << "\n=== Welcome to Canteen Management System ===\n";
        cout << "1. View Menu & Order\n";
        cout << "2. Exit\n";
        cout << "Enter your choice (1-2): ";
        cin >> choice;

        switch (choice) {
            case 1:
                canteenSystem.placeOrder();
                break;
            case 2:
                cout << "Exiting program. Goodbye!\n";
                break;
            default:
                cout << "Invalid choice. Please enter 1 or 2.\n";
        }
    } while (choice != 2);

    return 0;
}